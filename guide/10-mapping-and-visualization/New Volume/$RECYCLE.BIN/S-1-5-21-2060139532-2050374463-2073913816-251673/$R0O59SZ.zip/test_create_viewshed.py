import unittest
import datetime
import pandas as pd
from arcgis.gis import Item
import sys
import uuid
sys.path.append("D:\\Projects\\geosaurus\\tests\\")
sys.path.append("D:\\Projects\\geosaurus\\tests\\integration")
from arcgis.features import FeatureLayer
from arcgis.features.find_locations import create_viewshed
from utils.decorators import integration_test, profiles
from utils.data_utils import cleanup_published_items
from config import INTEGRATION_TEST_ITEM_TAG

data = [
     {
        "FID": 4,
        "NAME": "THE WHOLE ENCHILADA",
        "ADDR": "106 E YORBA LINDA BLVD",
        "OPTIONS": "Takeout, Delivery",
        "DISCOUNTS": "None",
        "NOTES": "*Doordash",
        "DEL_OPTS": "Doordash",
        "TYPE": "Mexican",
        "WEBSITE": "https://wholeenchilada.com",
        "Doordash": "https://www.doordash.com/store/the-whole-enchilada-placentia-56007/en-US",
        "Grubhub": " ",
        "Postmates": " ",
        "Other": " ",
        "OUTDINE": "Open",
        "SHAPE": {
            "x": -13120774.654751526,
            "y": 4013636.1349284584,
            "spatialReference": {"wkid": 102100, "latestWkid": 3857},
        }
     }
         ]



@profiles.agol
@integration_test
class TestCreateViewshed(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        # gather layers
        # create point layer in portal
        cls.published_items = []
        sdf = pd.DataFrame(data)
        layer_title = "viewshed"
        cls.point_item = cls.gis.content.import_data(
            df=sdf, title=layer_title, tags=INTEGRATION_TEST_ITEM_TAG
        )
        cls.published_items.append(cls.point_item)
        
        assert isinstance(cls.point_item, Item)
        cls.point_layer = cls.point_item.layers[0]
        assert isinstance(cls.point_layer, FeatureLayer)

    def test_overwrite(self):
        """tests overwriting an Item layer using the context param"""
        # create layer that will be overwritten
        test_id = str(datetime.datetime.now().microsecond)
        output_name = "viewshedresult"
        print("Creating ", output_name)
        target_item = create_viewshed(
            input_layer=self.point_layer, output_name=output_name
        )
        assert isinstance(target_item, Item)
        target_layer = target_item.layers[0]
        assert isinstance(target_layer, FeatureLayer)
        self.published_items.append(target_item)
        target_layer_count_1 = len(target_item.layers)

        # perform overwrite
        print("Creating overwrite layer")
        overwrite = create_viewshed(
            input_layer=self.point_layer,
            maximum_distance=5,
            output_name=target_layer,
            context={"overwrite": True},
        )
        assert isinstance(overwrite, Item)
        assert target_item.id == overwrite.id
        # overwrite only produces one layer
        assert len(target_item.layers) == target_layer_count_1
        # deleted content created by test
        assert target_item.delete(permanent=True)

    @classmethod
    def tearDownClass(cls):
        cleanup_published_items(cls.published_items)


if __name__ == "__main__":
    unittest.main()